﻿using System;

namespace Lab2
{
    class MainClass
    {
        public static double Power(int a, int b)
        {
            return Math.Pow((a / b), 3);
        }
        public static double Mult(double a, double b)
        {
            return a * b;
        }
        public static double Polina(int a, int b, int c, int d, int x)
        {
            double p = a * Math.Pow(x, 5) - 1 / b * Math.Pow(x, 4) + c * x + d;
            return p;
        }
        public static double Triangle(int a, int b, int c)
        {
            return a + b + c;

        }
        public static void Main(string[] args)

        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("#####MENU#####");
                Console.WriteLine("1.Вознесение в степень");
                Console.WriteLine("2.Умножение");
                Console.WriteLine("3.Полином");
                Console.WriteLine("4.Периметр триугольника");
                Console.WriteLine("5.Вывести данные");
                Console.Write("\n Введите команду: ");
                char ch = char.Parse(Console.ReadLine());

                switch (ch)
                {

                    case '1':
                        Console.WriteLine("Введите первое число: ");
                        int a = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Введите второе число: ");
                        int b = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine(Power(a, b));
                        Console.ReadKey();
                        break;
                    case '2':
                        Console.WriteLine("Введите первое число: ");
                        double c = Convert.ToDouble(Console.ReadLine());
                        Console.WriteLine("Введите второе число: ");
                        double d = Convert.ToDouble(Console.ReadLine());
                        Console.WriteLine(Mult(c, d));
                        Console.ReadKey();
                        break;
                    case '3':
                        Console.WriteLine("Введите первое число: ");
                        int e = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Введите второе число: ");
                        int f = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Введите третье число: ");
                        int g = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Введите четвёртое число: ");
                        int h = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Введите Х: ");
                        int x = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine(Polina(e, f, g, h, x));
                        Console.ReadKey();
                        break;
                    case '4':
                        Console.WriteLine("Введите первое число: ");
                        int i = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Введите второе число: ");
                        int j = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Введите третье число: ");
                        int k = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine(Triangle(i, j, k));
                        Console.ReadKey();
                        break;
                    case '5':
                        Console.WriteLine("Богатько, Александр, 18 лет, ИПЗ-12, 1 курс");
                        Console.ReadKey();
                        break;
                }
            }
        }
    }
}
