﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Lab6
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            while (true)
            {
                Console.WriteLine("#####MENU#####");
                Console.WriteLine("1.Calculator\n2.Write-Read\n\n0.Exit\nEnter command:");
                int com = char.Parse(Console.ReadLine());
                switch (com)
                {
                    case '1':
                        StreamReader s = new StreamReader("/Users/aleksandrbogatko/Desktop/Alexandr_Bogatko_IPZ-12.zip/OOP labs/Lab6/Lab6/input.txt");
                        Console.WriteLine("Enter expression: ");
                        string problem = s.ReadLine();
                        string[] pr = problem.Split(' ');
                        int a = Int32.Parse(pr[0]);
                        int b = Int32.Parse(pr[2]);
                        char op = char.Parse(pr[1]);
                        double res = 0;
                        switch (op)
                        {
                            case '+':
                                res = a + b;
                                break;
                            case '-':
                                res = a - b;
                                break;
                            case '*':
                                res = a * b;
                                break;
                            case '/':
                                res = a / (double)b;
                                break;
                            case '%':
                                res = a % b;
                                break;
                            case '^':
                                res = Math.Pow(a, b);
                                break;
                            default: break;
                        }
                        StreamWriter o = new StreamWriter("/Users/aleksandrbogatko/Desktop/Alexandr_Bogatko_IPZ-12.zip/OOP labs/Lab6/Lab6/output.txt");
                        o.WriteLine("Result is " + res.ToString());
                        s.Close();
                        o.Close();
                        break;
                    case '2':
                        string path = @"C:\SomeDir2";
                        DirectoryInfo dirInfo = new DirectoryInfo(path);
                        if (!dirInfo.Exists)
                        {
                            dirInfo.Create();
                        }
                        Console.WriteLine("Enter expression: ");
                        string text = Console.ReadLine();

                        using (FileStream fstream = new FileStream($"{path}\note.txt", FileMode.OpenOrCreate))
                        {
                            byte[] array = Encoding.Default.GetBytes(text);
                            fstream.Write(array, 0, array.Length);
                            Console.WriteLine("Expression have been written");
                        }
                        using (FileStream fstream = File.OpenRead($"{path}\note.txt"))
                        {
                            byte[] array = new byte[fstream.Length];
                            fstream.Read(array, 0, array.Length);
                            string textFromFile = Encoding.Default.GetString(array);
                            Console.WriteLine($"Text from file: {textFromFile}");
                        }
                        Console.ReadLine();
                        break;
                    case '0':
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("You enter wrong number.");
                        break;
                }

            }
        }
    }
}
