﻿using System;

class Unit : IComparable
{
    double value;

    public Unit(double weight)
    {
        this.value = weight;
    }

    /*Блок перегруженных операторов*/

    public static Unit operator +(Unit k1, Unit k2) => new Unit(k1.value + k2.value);

    public static Unit operator -(Unit k1, Unit k2) => new Unit(k1.value - k2.value);

    public static Unit operator *(Unit k1, Unit k2) => new Unit(k1.value * k2.value);

    public static Unit operator /(Unit k1, Unit k2) => new Unit(k1.value / k2.value);

    /*Реализация интерфейса IComparable*/
    public int CompareTo(object obj)
    {
        if (obj is Unit u)
        {
            return value.CompareTo(u.value);
        }
        return 0;
    }

    /*Вывод массы*/
    public void Print()
    {
        Console.WriteLine(value);
    }
    /*Функция округления*/
    public double Round()
    {
        value = Math.Round(value);
        return value;
    }

}
namespace lab13
{
    class Program
    {
        static void Main(string[] args)
        {
            Unit u1 = new Unit(8.4), u2 = new Unit(16), u3 = new Unit(22), u4;
            u4 = u1 + u2;
            u4 *= u2;
            u4 -= u3;
            u4 /= u1;

            u4.Print();
            u4.Round();
            u4.Print();
        }
    }
}
