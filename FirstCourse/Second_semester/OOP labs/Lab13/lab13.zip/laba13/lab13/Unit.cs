﻿using System;
using System.Collections.Generic;
using System.Text;

namespace lab13
{
    class Unit: IComparable
    {
        double value;

        public Unit(double weight)
        {
            this.value = weight;
        }

        /*Блок перегруженных операторов*/

        public static Unit operator +(Unit k1, Unit k2) => new Unit(k1.value + k2.value);

        public static Unit operator -(Unit k1, Unit k2) => new Unit(k1.value - k2.value);

        public static Unit operator *(Unit k1, Unit k2) => new Unit(k1.value * k2.value);

        public static Unit operator /(Unit k1, Unit k2) => new Unit(k1.value / k2.value);

        /*Реализация интерфейса IComparable*/
        public int CompareTo(object obj)
        {
            if (obj is Unit u)
            {
                return value.CompareTo(u.value);
            }
            return 0;
        }

        /*Вывод массы*/
        public void Print()
        {
            Console.WriteLine(value);
        }
        /*Функция округления*/
        public double Round()
        {
            value = Math.Round(value);
            return value;
        }

    }
}
