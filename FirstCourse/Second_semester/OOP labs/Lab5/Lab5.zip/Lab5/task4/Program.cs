﻿using System;
using System.Collections.Generic;

namespace task_4
{

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Task 4");
            Console.WriteLine("4. Статичнi класи. Розробити статичний клас з 3 методами");

            List<int>  arr = new List<int> {1, 2, 5, 3, 7, 5, 1, 3, 4};
            int MinElement = 1;
            int MaxElement = 7;
            Console.WriteLine("\nFirst method: ");
            Console.WriteLine("Min element: " + ArrayMethods.LinearSearch(arr, MinElement));
            Console.WriteLine("Max element: " + ArrayMethods.LinearSearch(arr, MaxElement));

            int[] arr_2 = new int[100];
            Random rand = new Random();
            Console.WriteLine("\nCreating array for second and third methods: ");
            for (int i = 0; i < arr_2.Length; i++)
            {
                arr_2[i] = rand.Next(61, 100);
                Console.WriteLine(arr_2[i].ToString() + " ");
            }
            int elementWeNeed_1 = arr_2[0];
            object elementWeNeed_2 = arr_2[1];
            Console.WriteLine("Second method: \nElement we need is: " + elementWeNeed_1);
            Console.WriteLine(ArrayMethods.BinarySearch(arr_2, elementWeNeed_1));
            Console.WriteLine("\nThird method:\nElement we need is: " + elementWeNeed_2);
            Console.WriteLine(ArrayMethods.ModifiedBinarySearch(arr_2, elementWeNeed_2));
        }
    }
}
