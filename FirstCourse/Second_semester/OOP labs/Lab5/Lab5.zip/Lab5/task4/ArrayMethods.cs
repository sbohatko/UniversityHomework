﻿using System;
using System.Collections.Generic;

namespace task_4
{
    class ArrayMethods
    {
        public static string LinearSearch(List<int> arr, int key)
        {
            for (int i = 0; i <= arr.Count; i++)
            {
                if (arr[i] == key)
                {
                    Console.WriteLine("Element is founded ");
                    break;
                }
            }
            return "key = " + key;
        }

        public static string BinarySearch(int[] arr, int key)
        {
            Array.Sort(arr);

            bool x = false;
            int begin, end, c;
            begin = 0;
            end = 100;
            while (begin < end)
            {
                c = begin + (end - begin) / 2;
                if (key < arr[c]) end = c;
                else if (key > arr[c]) begin = c + 1;
                else { x = true; break; }
            }
            if (x == true)
                Console.WriteLine("Element is founded.");
            return "key = " + key;
        }

        public static string ModifiedBinarySearch(int[] arr, object key)
        {
            Array.Sort(arr);

            int res = Array.BinarySearch(arr, key);

            if (res < 0)
            {
                Console.WriteLine("\nThe element to search for "
                                      + "({0}) is not found.",
                                  key);
            }

            else
            {
                Console.WriteLine("The element to search for "
                                      + "({0}) is at index {1}.",
                                  key, res);
            }
            return "key = " + key;
        }
    }
}

