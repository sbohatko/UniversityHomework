﻿using System;

namespace Lab5
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Variant 2, task 1");
            Console.WriteLine("Модифiкувати приклад таким чином, щоб можна було обчислювати середнiй рейтинг за 2 кредити(за семестр).");

            var student_1 = Student.NewStudent();
            Console.WriteLine(student_1.name);
            Console.WriteLine(student_1.lastName);
            Console.WriteLine(student_1.adress);
            Console.WriteLine(student_1.age);
            Console.WriteLine(student_1.passport);
            Console.WriteLine(student_1.telephone);

            student_1.MyRating();
            
            

        }
    }
}
