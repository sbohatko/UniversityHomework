﻿using System;
using System.IO;

namespace Lab5
{
    class Student
    {

        private string Name;
        private string LastName;
        private string Adress;
        private string Passport;
        private int Age;
        private string Telephone;
        private int Rating;

        public Student()
        {

        }


        public string name
        {
            get => Name;
            set => Name = value;
        }

        public string lastName
        {
            get => LastName;
            set => LastName = value;
        }

        public string adress
        {
            get => Adress;
            set => Adress = value;
        }

        public string passport
        {
            get => Passport;
            set => Passport = value;
        }

        public int age
        {
            get => Age;
            set => Age = value;
        }

        public string telephone
        {
            get => Telephone;
            set => Telephone = value;
        }

        public int rating
        {
            get => Rating;
            set => Rating = value;
        }

        public void StudentRating(int R)
        {
            Rating = R;
            if (Rating >= 80)
            {
                Console.WriteLine("Cool!");
            }
            else if (Rating <= 30)
            {
                Console.WriteLine("You should learn better!");
            }
            else
            {
                Console.WriteLine("Nice try)");
            }
        }

        public static Student NewStudent()
        {
            var student = new Student();
            bool stayVariable = true;
            int helpVariable;
            do
            {
                Console.WriteLine("Hello! Enter your name: ");
                student.Name = Console.ReadLine();
                if (student.Name.Length > 1)
                {
                    Console.WriteLine("Great! Enter your lastname: ");
                    student.LastName = Console.ReadLine();
                    if (student.LastName.Length > 1)
                    {
                        Console.WriteLine("And enter your age: ");
                        student.Age = Convert.ToInt32(Console.ReadLine());
                        if (student.Age >= 16)
                        {
                            Console.WriteLine("A few more questions! Enter your adress: ");
                            student.Adress = Console.ReadLine();
                            Console.WriteLine("And your passport: ");
                            student.Passport = Console.ReadLine();
                            Console.WriteLine("Last, but not least. Enter your phone number: ");
                            student.Telephone = Console.ReadLine();
                            Console.WriteLine("Finally the last, enter your rating: ");
                            student.Rating = Convert.ToInt32(Console.ReadLine());
                            string writepath = @"Users\AlexBogatko\Desktop\labs\Students.txt";
                            try
                            {
                                using (StreamWriter sw = new StreamWriter(writepath, false, System.Text.Encoding.Default))
                                {
                                    sw.WriteLine(student.name);
                                    sw.WriteLine(student.lastName);
                                    sw.WriteLine(student.age);
                                    sw.WriteLine(student.adress);
                                    sw.WriteLine(student.passport);
                                    sw.WriteLine(student.telephone);
                                    sw.WriteLine(student.rating);
                                }
                            }
                            catch (Exception e)
                            {
                                Console.WriteLine(e.Message);
                            }


                            Console.WriteLine("If u want to exit press 0. And if you want to fill the form again press 1.");
                            helpVariable = Convert.ToInt32(Console.ReadLine());
                            stayVariable = Convert.ToBoolean(helpVariable);
                        }
                        else
                        {
                            Console.WriteLine("Oops... U r not a student!");
                        }
                    }
                    else
                    {
                        Console.WriteLine("Oops... U should enter your lastname");
                    }
                }
                else
                {
                    Console.WriteLine("Oops... U should enter your name");
                }
            } while (stayVariable);
            return student;
        }

        St_Asessment straiting1 = new St_Asessment();
        St_Asessment straiting2 = new St_Asessment();
        
        public void MyRating()
        {
            double rating_1 = straiting1.StRating();
            Console.WriteLine("First credit: " + rating_1);
            double rating_2 = straiting2.StRating();
            Console.WriteLine("First credit: " + rating_2);
            double averageRating = (rating_1 + rating_2) / 2;
            Console.WriteLine("Average rating: " + Math.Round(averageRating, 4));
        }
    }
}

