﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lab5
{
    class St_Asessment
    {
        static double FindAverageAssesment(int[] array)
        {
            double averageAssesment = 0;
            foreach (int element in array)
            {
                averageAssesment += element;
            }
            averageAssesment = averageAssesment / array.Length;
            
            return averageAssesment;
        }

        public double StRating()
        {
            int[] assesment = new int[7];
            Random rand = new Random();
            for(int i = 0; i<assesment.Length; i++)
            {
                assesment[i] = rand.Next(61, 100);
                Console.Write(assesment[i].ToString() + "\n");
            }

             return Math.Round(FindAverageAssesment(assesment), 4);
        }

    }
}
