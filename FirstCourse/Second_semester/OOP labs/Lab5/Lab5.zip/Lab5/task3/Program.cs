﻿using System;
using System.Collections.Generic;

namespace task_3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Task 3");
            Console.WriteLine("Частковi класи. Розбити клас Кафедра на 2 частини.\n");

            Department SoftwareSyst = new Department();
            SoftwareSyst.Name = "Department of software systems and technology";
            SoftwareSyst.AmountOfProfessors = 10;
            SoftwareSyst.WriteDepartmentName();
            SoftwareSyst.WriteAmountOfProfessors();

            List<string> disiplinesSoftTech = new List<string>() { "AK", "ВOOП", "ОПI", "AСД", "BДУС", "ДМ", "Iноземна мова", "Осн математики", "Осн програмування", "Iнтернет мережi", "Фiлософiя", "Веб-технологiї" };
            SoftwareSyst.WriteDiciplines(disiplinesSoftTech);

        }
    }
}
