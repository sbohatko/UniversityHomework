﻿using System;


namespace task3
{
    public partial class Department
    {
        private string name;
        private int amountOfProfessors;


        public Department()
        {

        }

        public string Name
        {
            get => name;
            set => name = value;
        }

        public int AmountOfProfessors
        {
            get => amountOfProfessors;
            set => amountOfProfessors = value;
        }

        public void WriteDepartmentName()
        {
            Console.WriteLine("Department name: " + name); ;
        }
    }
}
