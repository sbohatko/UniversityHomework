﻿using System;
using System.Collections.Generic;


namespace task3
{
    public partial class Department
    {
        public void WriteAmountOfProfessors()
        {
            Console.WriteLine("Amount of Professors: " + amountOfProfessors);

        }

        public void WriteDiciplines(List<string> disciplines)
        {
            foreach (string element in disciplines)
            {
                Console.WriteLine("Discipline: " + element);
            }

            Console.WriteLine("Amount of disciplines: " + disciplines.Count + "\n");
        }
    }
}
