﻿using System;
using System.Collections.Generic;

namespace task_2
{
    class Faculty
    {
        private string name;

        public Faculty()
        {

        }

        public string Name
        {
            get => name;
            set => name = value;
        }

        class Department
        {
            private string name;
            private int amountOfProfessors;


            public Department()
            {

            }

            public void WriteDiciplines(List<string> disciplines)
            {
                foreach (string element in disciplines)
                {
                    Console.WriteLine("Discipline: " + element);
                }

                Console.WriteLine("Amount of disciplines: " + disciplines.Count + "\n");
            }

            public string Name
            {
                get => name;
                set => name = value;
            }

            public int AmountOfProfessors
            {
                get => amountOfProfessors;
                set => amountOfProfessors = value;
            }

            public void WriteDepartmentName()
            {
                Console.WriteLine("Department name: " + name); ;
            }

            public void WriteAmountOfProfessors()
            {
                Console.WriteLine("Amount of Professors: " + amountOfProfessors);
            }


            class Professor : Faculty
            {
                private string fullname;
                private string discipline;

                public Professor(string fullname, string discipline)
                {
                    this.fullname = fullname;
                    this.discipline = discipline;
                }
            }
        }

        Department SoftwareSyst = new Department();
        Department InternetTechnology = new Department();

        public void WriteInformDepartments()
        {
            SoftwareSyst.Name = "Department of software systems and technology";
            SoftwareSyst.AmountOfProfessors = 10;
            SoftwareSyst.WriteDepartmentName();
            SoftwareSyst.WriteAmountOfProfessors();

            InternetTechnology.Name = "Network and Internet department";
            InternetTechnology.AmountOfProfessors = 10;
            InternetTechnology.WriteDepartmentName();
            InternetTechnology.WriteAmountOfProfessors();

            List<string> disiplinesSoftTech = new List<string>() { "AK", "ВOOП", "ОПI", "AСД", "BДУС", "ДМ", "Iноземна мова", "Осн математики", "Осн програмування", "Iнтернет мережi", "Фiлософiя", "Веб-технологiї" };
            SoftwareSyst.WriteDiciplines(disiplinesSoftTech);
            List<string> disiplinesInternetTech = new List<string>() { "ВДУС", "Фiзика", "Iноземна мова", "Осн iнформ безпеки", "Фiлософiя", "НОС", "Технологiї програмування", "АК", "ТССА", "ОС", "ТПММ", "СПС", };
            InternetTechnology.WriteDiciplines(disiplinesInternetTech);

        }
    }
}
