﻿using System;

namespace task2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Task 2");
            Console.WriteLine("Створити iєрархiю класiв: Факультет, Викладач. Створити клас Кафедра, вкладений в клас Факультет. В класi Факультет створити 2 екземпляри класу Кафедра. В класi Кафедра реалiзувати 3 методи \n");

            Faculty InformationTech = new Faculty();
            InformationTech.Name = "Information Technology Faculty";
            Console.WriteLine(InformationTech.Name);
            InformationTech.WriteInformDepartments();
            
        }
    }
}
