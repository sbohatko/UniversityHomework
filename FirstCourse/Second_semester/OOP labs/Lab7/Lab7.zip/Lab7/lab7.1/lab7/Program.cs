﻿using System;
using System.Collections.Generic;

namespace lab7
{
    public class Employer : IComparable<Employer>
    {
        public string _name { get; set; }
        public string _lastName { get; set; }
        public int _age { get; set; }
        public int _salary { get; set; }

        public Employer()
        {

        }

        public Employer(string name, string lastName, int age, int salary)
        {
            this._name = name;
            this._lastName = lastName;
            this._age = age;
            this._salary = salary;
        }

        public int CompareTo(Employer other)
        {
            if (other == null) return 2;

            return _age.CompareTo(other._age);
        }
    }
    class Program
    {
        public static void CompareResultWriter(int res)
        {
            switch (res)
            {
                case 1:
                    Console.WriteLine("Age of first person >");
                    break;
                case -1:
                    Console.WriteLine("Age of second person <");
                    break;
                case 0:
                    Console.WriteLine("Equal.");
                    break;
                case 2:
                    Console.WriteLine("Obj = null");
                    break;
                default:
                    Console.WriteLine("Something wrong.");
                    break;
            }
        }
        static void Main(string[] args)
        {
                List<Employer> emps = new List<Employer>();

                var emp1 = new Employer("John", "Wick", 30, 800);
                emps.Add(emp1);
                var emp2 = new Employer("Lana", "Rhodes", 22, 1000);
                emps.Add(emp2);
                var emp3 = new Employer("Piper", "Perry", 22, 1000);
                emps.Add(emp3);
                var emp4 = new Employer("Bob", "Ross", 78, 1150);
                emps.Add(emp4);
                var emp5 = new Employer("Elton ", "John", 23, 1150);
                emps.Add(emp5);

                int result1 = emps[0].CompareTo(emps[1]);
                CompareResultWriter(result1);
                int result2 = emps[1].CompareTo(emps[2]);
                CompareResultWriter(result2);
                int result3 = emps[2].CompareTo(emps[3]);
                CompareResultWriter(result3);
                int result4 = emps[3].CompareTo(emps[4]);
                CompareResultWriter(result4);

                Console.ReadKey();
            }
        }
    }


