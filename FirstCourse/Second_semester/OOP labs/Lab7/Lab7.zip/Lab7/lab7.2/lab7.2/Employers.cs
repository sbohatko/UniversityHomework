﻿using System;
using System.Collections;

namespace lab7
{


    public class Employer : IComparable<Employer>
    {
        private class SortByAgeAscending : IComparer
        {
            int IComparer.Compare(object x, object y)
            {
                Employer e1 = (Employer)x;
                Employer e2 = (Employer)y;

                if (e1._age > e2._age)
                    return 1;
                if (e1._age < e2._age)
                    return -1;
                else
                    return 0;

            }
        }

        private class SortByAgeDescending : IComparer
        {
            int IComparer.Compare(object x, object y)
            {
                Employer e1 = (Employer)x;
                Employer e2 = (Employer)y;

                if (e1._age < e2._age)
                    return 1;
                if (e1._age > e2._age)
                    return -1;
                else
                    return 0;

            }
        }

        private class SortBySalaryAscending : IComparer
        {
            int IComparer.Compare(object x, object y)
            {
                Employer e1 = (Employer)x;
                Employer e2 = (Employer)y;

                if (e1._salary > e2._salary)
                    return 1;
                if (e1._salary < e2._salary)
                    return -1;
                else
                    return 0;

            }
        }

        private class SortBySalaryDescending : IComparer
        {
            int IComparer.Compare(object x, object y)
            {
                Employer e1 = (Employer)x;
                Employer e2 = (Employer)y;

                if (e1._salary < e2._salary)
                    return 1;
                if (e1._salary > e2._salary)
                    return -1;
                else
                    return 0;

            }
        }


        public string _name { get; set; }
        public string _lastName { get; set; }
        public int _age { get; set; }
        public int _salary { get; set; }

        public Employer()
        {

        }

        public Employer(string name, string lastName, int age, int salary)
        {
            this._name = name;
            this._lastName = lastName;
            this._age = age;
            this._salary = salary;
        }

        public int CompareTo(Employer other)
        {
            if (other == null) return 2;

            return _age.CompareTo(other._age);
        }


        public static IComparer sortAgeAscending()
        {
            return (IComparer)new SortByAgeAscending();

        }

        public static IComparer sortAgeDescending()
        {
            return (IComparer)new SortByAgeDescending();

        }

        public static IComparer sortSalaryAscending()
        {
            return (IComparer)new SortBySalaryAscending();

        }

        public static IComparer sortSalaryDescending()
        {
            return (IComparer)new SortBySalaryDescending();

        }
    }
}

