﻿using System;

namespace lab7
{
    class Program
    {
        public static void ArrayWriter(Employer[] arr)
        {
            foreach (Employer person in arr)
            {
                Console.WriteLine(person._name + "\t\t" + person._lastName + "\t\t" + person._age + "\t\t" + person._salary);
            }
        }

        public static void HeadingWriter(string str)
        {
            Console.WriteLine("\nSorted emps by" + str);
        }

        static void Main(string[] args)
        {

            Employer[] emps = new Employer[5]
            {
                new Employer("Bob", "Marley", 45, 750),
                new Employer("George", "Bush", 51, 1200),
                new Employer("Bob", "Dylan", 30, 2000),
                new Employer("John", "Travolta", 35, 1000),
                new Employer("Johny", "Cage", 23, 1500)
            };
            while (true)
            {
                Console.Write("\tMENU\n" +
                    "1.Show array\n" +
                    "2.Sort by age(Ascending)\n" +
                    "3.Sort by age(Descending)\n" +
                    "4.Sort by salary(Ascending)\n" +
                    "5.Sort by salary(Descending)\n\n" +
                    "0.Exit\nChoose command:");
                int command = char.Parse(Console.ReadLine());
                Console.Clear();
                switch (command)
                {
                    case '1':
                        Console.WriteLine("\nUnsorted array:");
                        Console.WriteLine("Name\t\tLast name\tAge\t\tSalary\n");
                        ArrayWriter(emps);
                        break;

                    case '2':
                        HeadingWriter(" Age(Ascending):\n");
                        Array.Sort(emps, Employer.sortAgeAscending());
                        Console.WriteLine("Name\t\tLast name\tAge\t\tSalary\n");
                        ArrayWriter(emps);
                        break;

                    case '3':
                        HeadingWriter(" Age(Descending):\n");
                        Array.Sort(emps, Employer.sortAgeDescending());
                        Console.WriteLine("Name\t\tLast name\tAge\t\tSalary\n");
                        ArrayWriter(emps);
                        break;


                    case '4':
                        HeadingWriter(" Salary(Ascending):\n");
                        Array.Sort(emps, Employer.sortSalaryAscending());
                        Console.WriteLine("Name\t\tLast name\tAge\t\tSalary\n");
                        ArrayWriter(emps);
                        break;


                    case '5':
                        HeadingWriter(" Salary(Descending):\n");
                        Array.Sort(emps, Employer.sortSalaryDescending());
                        Console.WriteLine("Name\t\tLast name\tAge\t\tSalary\n");
                        ArrayWriter(emps);
                        break;

                    case '0':
                        Console.Clear();
                        Console.WriteLine("Bye bye.");
                        Environment.Exit(0);
                        break;

                    default:
                        break;

                }
            }
        }
    }
}

