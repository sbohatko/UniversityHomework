﻿using System;


namespace lab11
{
    /*Создадим клас Умный холодильнык
    с такими параметрами как статус,цвет,название,ширина,высота и содержимое*/
    class SmartRef {
        private bool status;                                  
        private string color;                                 
        private string name;
        private int width;
        private int height;
        private int frostlevel;
        private int content;

        public int Content {
            get { return content; }
            set { content = value; }
        }
        public bool Status {
            get { return status; }
            set { status = value; }
        }
        public string Color {
            get { return color; }
            set { color = value; }
        }
        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        public int Width
        {
            get { return width; }
            set { width = value; }
        }
        public int Height
        {
            get { return height; }
            set { height = value; }
        }
        public int Frostlevel
        {
            get { return frostlevel; }
            set { frostlevel = value; }
        }


        /*Cоздадим так же несколько методов:
         * Включение,
         * выключение,
         * настройку температуры,
         * наполнение продуктами,
         * проверка на наличие продуктов,
         * вывод*/

        public void TurnON()                           
        {
            Console.WriteLine("\nRefrigerator was turned ON");
            status = true;
        }
        public void TurnOFF()
        {
            Console.WriteLine("\nRefrigerator was turned OFF");
            status = false;
        }
        public void FrostLevel()
        {
            Console.WriteLine("\nPlease enter frost level you want: ");
            frostlevel = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine($"\nFrost level was set on {frostlevel}");
        }
        public void FoodAdd()
        {
            Console.WriteLine("How much food you want to add? :");
            content += Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("\nFood added.");
        }
        public void FoodCheck()
        {
            if (content == 0) { Console.WriteLine("There is no food"); }    
            if (0 <= content && content < 5) { Console.WriteLine("There is some food"); }
            if (5 <= content && content < 10) { Console.WriteLine("There is enough food"); }
            if (content >= 10) { Console.WriteLine("There is a lot of food"); }
        }
        public void WriteInfo()
        {
            Console.WriteLine($"Refrigerators:\n{status}, {color}, {name}, {frostlevel}, {content}, {width}, {height}\n");
        }

    }

    class MainClass
    {
        public static void Main(string[] args)
        {
            //Создадим 3 экземпляра класса SmartRef

            SmartRef sr1 = new SmartRef
            {
                Status = false,
                Color = "Black",
                Name = "LG",
                Width = 500,
                Height = 1200,
                Frostlevel = 0,
                Content = 0
            };       

            SmartRef sr2 = new SmartRef
            {
                Status = false,
                Color = "White",
                Name = "Samsung",
                Width = 600,
                Height = 1500,
                Frostlevel = 0,
                Content = 0
            };

            SmartRef sr3 = new SmartRef
            {
                Status = false,
                Color = "Yellow",
                Name = "Bosch",
                Width = 500,
                Height = 500,
                Frostlevel = 0,
                Content = 0
            };

                sr1.WriteInfo();
                sr2.WriteInfo();
                sr3.WriteInfo();

                /* Зададим температуру для холодильника №1.
                Включим холодильники №1  №2 и №3.
                и добавим еду в холодильник №3 и 2 */
                sr1.FrostLevel();
                sr1.TurnON();
                sr2.TurnON();
                sr3.TurnON();
                sr2.FoodAdd();
                sr3.FoodAdd();

                sr1.WriteInfo();
                sr2.WriteInfo();
                sr3.WriteInfo();

                //Проверим холодильники на наличие еды
                sr2.FoodCheck();
                sr3.FoodCheck();


        }
    }
}
