﻿using System;
using System.IO;

namespace Lab1
{
    public class Student
    {
        private string Name;
        private string LastName;
        private string Adress;
        private string Passport;
        private int Age;
        private string Telephone;
        private int Rating;

        public Student()
        {
            //конструктор без параментров 
        }

        public string name
        {
            get
            {
                return Name;
            }
            set
            {
                Name = value;
            }
        }

        public string lastname
        {
            get
            {
                return LastName;
            }
            set
            {
                LastName = value;
            }
        }


        public string adress
        {
            get
            {
                return Adress;
            }
            set
            {
                Adress = value;
            }
        }

        public string passport
        {
            get
            {
                return Passport;
            }
            set
            {
                Passport = value;
            }
        }


        public int age
        {
            get
            {
                return Age;
            }
            set
            {
                Age = value;
            }
        }

        public string phone
        {
            get
            {
                return Telephone;
            }
            set
            {
                Telephone = value;
            }
        }

        public int rating
        {
            get
            {
                return Rating;
            }
            set
            {
                Rating = value;
            }

        }

        public void WriteInfo(string text)
        {
            StreamWriter sw = new StreamWriter(@"/Users/aleksandrbogatko/Desktop/Alexandr_Bogatko_IPZ-12.zip/OOP labs/Lab1/code/lab_database.txt", true);
            sw.WriteLine(text);
            sw.Close();
        }

        class Program
        {
            static void Main(string[] args)
            {
                Console.WriteLine("######MENU#####\n");
                Console.WriteLine("1.Добавить студента");
                Console.WriteLine("2.Вывести таблицу студентов\n");
                Console.WriteLine("0.Выйти");
                while (true)
                {
                    Console.Write("\nВведите команду: ");
                    char ch = char.Parse(Console.ReadLine());
                    switch (ch)
                    {

                        case '1':
                            Student s1 = new Student();

                            Console.WriteLine("Введите имя: ");
                            s1.name = Console.ReadLine();

                            Console.WriteLine("Введите фамилию: ");
                            s1.lastname = Console.ReadLine();

                            Console.WriteLine("Введите адрес: ");
                            s1.adress = Console.ReadLine();

                            Console.WriteLine("Введите номер паспорта:");
                            s1.passport = Console.ReadLine();

                            Console.WriteLine("Введите возраст: ");
                            s1.age = Convert.ToInt32(Console.ReadLine());

                            Console.WriteLine("Введите номер телефона: ");
                            s1.phone = Convert.ToString(Console.ReadLine());

                            Console.WriteLine("Введите рейтинг: ");
                            s1.rating = Convert.ToInt32(Console.ReadLine());

                            string text = Convert.ToString((s1.name, s1.lastname, s1.adress, s1.passport, s1.age, s1.phone, s1.rating));
                            s1.WriteInfo(text);

                            Console.WriteLine("Ваши данные: \n\n" + text);
                            if (s1.rating >= 80) { Console.WriteLine("Привет отличникам!"); }
                            if (s1.rating <= 30) { Console.WriteLine("Нужно учиться лучше!"); }
                            if (30>=s1.rating && s1.rating<=80){ Console.WriteLine("Можно учиться лучше!"); }
                            Console.ReadKey();
                            Console.Clear();
                            break;

                        case '2':
                            Console.WriteLine(File.ReadAllText(@"/Users/aleksandrbogatko/Desktop/Alexandr_Bogatko_IPZ-12.zip/OOP labs/Lab1/code/lab_database.txt"));
                            break;

                        case '0':
                                Environment.Exit(0);
                            break;

                        default: break;
                    }
                }
            }
        }
    }
}