﻿using System;
namespace lab1
{
    public class MyClass
    {
        public MyClass()
        {
        }
    }
}
