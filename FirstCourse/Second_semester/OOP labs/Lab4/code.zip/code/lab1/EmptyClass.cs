﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Lab1
{
    class Student
    {
        public string Name; //имя
        public int Age;  // возраст
        public string Role; // роль
        public string Facultet;
        public string Group;
        public int Course;
        public int Rating;

        public Student(string N, int A, string R, string F, string G, int C)
        {
            //конструктор з параметрами 
            Name = N;
            Age = A;
            Role = R;
            Facultet = F;
            Group = G;
            Course = C;
        }
        public void StudentRating(int R)
        {
            Rating = R;
            if (Rating >= 80)
                Console.WriteLine("Привіт відмінникам");
            else
                if (Rating <= 30)
                Console.WriteLine("Треба вчитися краще!");
            else
                Console.WriteLine("Можна вчитися ще краще!");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            //дані рейтингу
            //ініціалізація полів класу виконується в конструкторі з параметрами
            Student newStudent = new Student("Бака", 20, "студент", "КННІ", "K-01", 3);
            Console.WriteLine("Хто ви?");
            Console.WriteLine("Прізвище = " + newStudent.Name);
            Console.WriteLine("Вік= " + newStudent.Age);
            Console.WriteLine("Роль= " + newStudent.Role);
            Console.WriteLine("Факультет = " + newStudent.Facultet);
            Console.WriteLine("група= " + newStudent.Group);
            Console.WriteLine("курс= " + newStudent.Course);
            Console.WriteLine("Ваш рейтинг?");
            string r = Console.ReadLine();
            newStudent.Rating = int.Parse(r);
            newStudent.StudentRating(newStudent.Rating);
            Console.ReadLine();
        }
    }
}

