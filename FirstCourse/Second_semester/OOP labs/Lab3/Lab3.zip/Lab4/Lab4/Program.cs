﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4
{
    class MainClass
    {
        public struct employer
        {
            public string Name;
            public int Jan;
            public int Feb;
            public int Mar;
            public int Apr;
            public int May;
            public int June;
            public int July;
            public int Aug;
            public int Sept;
            public int Octo;
            public int Nov;
            public int Dec;
            public int Overral;
        }
        static List<uint> Eratosthenes(uint n)//метод Ератосфена
            {
                var numbers = new List<uint>();
                //заполнение списка числами от 2 до n-1
                for (var i = 2u; i < n; i++)
                {
                    numbers.Add(i);
                }

                for (var i = 0; i < numbers.Count; i++)
                {
                    for (var j = 2u; j < n; j++)
                    {
                        //удаляем кратные числа из списка
                        numbers.Remove(numbers[i] * j);
                    }
                }

                return numbers;
            }
        static double Func(double x, double x2)//функция поиска корней уравнения методом Ньютона
        {
            double y = Math.Pow((x2 - 6 * x),2) - 2*Math.Pow((x - 3), 2);
            return y;
        }
        public static List<employer> list;
        public static void Main(string[] args)
        {
            while (true) {
                Console.Clear();
                Console.WriteLine("#####MENU#####");
                Console.WriteLine("1.Простые числа диапазона");
                Console.WriteLine("2.Диапазон рандомных чисел");
                Console.WriteLine("3.Зарплата работников");
                Console.WriteLine("4.Метод Ньютона");
                Console.WriteLine("5.Макс. Мин. чисел");
                Console.WriteLine("6.Метод линейного поиска");
                Console.WriteLine("7.Метод линейного поиска Маx, Min");
                Console.WriteLine("8.Двоичный поиск");
                Console.Write("Введите команду: ");
                char ch = char.Parse(Console.ReadLine());
            switch (ch)
            {
                case '1':
                    Console.Write("Введите число N = ");
                    var n = Convert.ToUInt32(Console.ReadLine());
                    var primeNumbers = Eratosthenes(n);
                    Console.WriteLine("Простые числа: ", n);
                    Console.WriteLine(string.Join(", ", primeNumbers));
                    Console.ReadKey();
                    break;
                case '2':
                        Console.Write("Введите количество чисел: ");
                        int j = Convert.ToInt32(Console.ReadLine());
                        int[] M = new int[j];
                        Random aRand = new Random();
                        int i;
                        int sum = 0;
                        Console.WriteLine("Массив: ");
                        for (i = 0; i < j; i++)
                        {
                            M[i] = aRand.Next(j);
                            Console.Write(M[i] + " ");
                            sum += M[i];
                        }
                        int Mid = sum / j;
                        double Root = Math.Sqrt(sum);
                        Console.WriteLine("\nСумма элементов массива: " + sum);
                        Console.WriteLine("Среднее арифметическое: " + Mid);
                        Console.WriteLine("Квадратный корень: " + Root);
                        Console.WriteLine("Максимальное число: " + M.Max());
                        Console.WriteLine("Минимальное число: " + M.Min());
                        Console.ReadKey();
                        break;
                    case '3':
                        list = new List<employer>();
                        Console.Write("Количество сотрудников:");
                        int col = Convert.ToInt32(Console.ReadLine());
                        for (int f = 0; f < col; f++)
                        {
                            Console.WriteLine("Сотрудник №" + (f + 1));
                            employer Emp = new employer();
                            Console.Write("Введите имя сотрудника: ");
                            Emp.Name = Convert.ToString(Console.ReadLine());
                            Console.Write("Введите зарплату за Январь: ");
                            Emp.Jan = Convert.ToInt32(Console.ReadLine());
                            Console.Write("Введите зарплату за Февраль: ");
                            Emp.Feb = Convert.ToInt32(Console.ReadLine());
                            Console.Write("Введите зарплату за Март: ");
                            Emp.Mar = Convert.ToInt32(Console.ReadLine());
                            Console.Write("Введите зарплату за Апрель:");
                            Emp.Apr = Convert.ToInt32(Console.ReadLine());
                            Console.Write("Введите зарплату за Май: ");
                            Emp.May = Convert.ToInt32(Console.ReadLine());
                            Console.Write("Введите зарплату за Июнь: ");
                            Emp.June = Convert.ToInt32(Console.ReadLine());
                            Console.Write("Введите зарплату за Июль: ");
                            Emp.July = Convert.ToInt32(Console.ReadLine());
                            Console.Write("Введите зарплату за Август: ");
                            Emp.Aug = Convert.ToInt32(Console.ReadLine());
                            Console.Write("Введите зарплату за Сентябрь:");
                            Emp.Sept = Convert.ToInt32(Console.ReadLine());
                            Console.Write("Введите зарплату за Октябрь:");
                            Emp.Octo = Convert.ToInt32(Console.ReadLine());
                            Console.Write("Введите зарплату за Ноябрь: ");
                            Emp.Nov = Convert.ToInt32(Console.ReadLine());
                            Console.Write("Введите зарплату за Декабрь: ");
                            Emp.Dec = Convert.ToInt32(Console.ReadLine());
                            Console.Clear();
                            Emp.Overral = Emp.Jan + Emp.Feb + Emp.Mar + Emp.Apr + Emp.May + Emp.June + Emp.July + Emp.Aug + Emp.Sept + Emp.Octo + Emp.Nov + Emp.Dec;
                            list.Add(Emp);
                            Console.WriteLine("Имя работника: "+ list[f].Name + "\n" + "Зарплата по месяцам: " + list[f].Jan + "\t" + list[f].Feb + "\t" + list[f].Mar + "\t" + list[f].Apr + "\t" +
                list[f].May + "\t" + list[f].June + "\n" + list[f].July + "\t" + list[f].Aug + "\t" + list[f].Sept + "\t" + list[f].Octo + "\t" + list[f].Nov + "\t" + list[f].Dec + "\n" + "Всего за год: " + list[f].Overral + "\n");
                        }
                        Console.ReadKey();
                        break;
                    case '4':
                        Console.Write("Введите x1: ");
                        int x1 = Convert.ToInt32(Console.ReadLine());
                        Console.Write("Введите x2: ");
                        int x2 = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Само уравнение: (x2-6*x)^2 -2(x-3)^2 = 81");
                        Console.WriteLine(Func(x1, x2));
                        Console.ReadKey();
                        break;
                    case '5':
                        Console.WriteLine("Введите числа: ");
                        int nums = Convert.ToInt32(Console.ReadLine());
                        int nums1 = Convert.ToInt32(Console.ReadLine());
                        int nums2 = Convert.ToInt32(Console.ReadLine());
                        int[] Mass = new int[3] {nums, nums1, nums2 };
                        Console.WriteLine("Заданный массив:");
                        for (int l = 0; l < Mass.Length; l++)
                        {
                            Console.Write(Mass[l] + " ");
                        }
                        Console.WriteLine("\nМаксимальный элемент: " + Mass.Max());
                        Console.WriteLine("Минимальный элемент: " + Mass.Min());
                        Console.ReadKey();
                        break;
                    case '6':
                        int[] a = new int[9] { 1, 2, 5, 3, 7, 5, 1, 3, 4 };
                        Console.WriteLine("Массив: ");
                        int count = 0;
                            for (int f = 0;f < a.Length; f++)
                        {
                            Console.Write(a[f]+" ");
                            count =+ f;
                        }
                        Console.WriteLine("\nДлина массива: " + count+1);
                        Console.ReadKey();
                        break;
                    case '7':
                        int[] Arr = new int[8] { 4, 5, 2, 3, 8, 7, 6, 1 };
                        Console.WriteLine("Массив: ");
                        int MinValue = Arr[0];
                        int MaxValue = Arr[0];
                        for(int p = 0; p < Arr.Length; p++)
                        {
                            Console.Write(Arr[p] + " ");
                            if (Arr[p] < MinValue)
                            {
                                MinValue = Arr[p];
                            }
                            else
                            {
                                MaxValue = Arr[p];
                            }
                        }
                        Console.WriteLine("\nНаименьший элемент: " + MinValue);
                        Console.WriteLine("Наибольший элемент: " + MaxValue);
                        Console.ReadKey();
                        break;
                    case '8':
                        int y, k, key, begin, end, c;
                        bool x = false;
                        Console.WriteLine("Размер массива");
                        k = int.Parse(Console.ReadLine());
                        int[] mas = new int[k];
                        Console.WriteLine("Нужный элемент");
                        key = int.Parse(Console.ReadLine());
                        for (y = 0; y < k; y++)
                        {
                            mas[y] = k * y;
                            Console.Write(mas[y] + " ");
                        }
                        begin = 0; end = k; 
                        while (begin < end)
                        {
                            c = begin + (end - begin) / 2;
                            if (key < mas[c]) end = c;
                            else if (key > mas[c]) begin = c + 1;
                            else { x = true; break; }
                        }
                        if (x == true)
                            Console.WriteLine("Елемент найден");
                        else Console.WriteLine("\nЕлемент не найден");
                        Console.ReadKey();

                        break;
            }
            
            }
        }
    }
 }
