﻿using System;
namespace Lab3
{
    public class EmptyClass
    {
        public EmptyClass()
        {
        }
    }
}
