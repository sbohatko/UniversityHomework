﻿using System;

namespace Lab3
{
    class MainClass
    {
        public static string Month(int a)
        {
            switch (a)
            {
                case 1:
                    return "\nЯнварь";
                case 2:
                    return "\nФевраль";
                case 3:
                    return "\nМарт";
                case 4:
                    return "\nАпрель";
                case 5:
                    return "\nМай";
                case 6:
                    return "\nИюнь";
                case 7:
                    return "\nИюль";
                case 8:
                    return "\nАвгуст";
                case 9:
                    return "\nСентябрь";
                case 10:
                    return "\nОктябрь";
                case 11:
                    return "\nНоябрь";
                case 12:
                    return "\nДекабрь";
                default:
                    return "\nВы ввели неверное число";
            }
        }
        public static double Func(double a)
        {
            if (a > 0)
            {
                return Math.Pow(a, 2) + 2;
            }
            return 0;
        }
        public static double Cycle(double n, int k)
        {
            double sum = 0;
            for (int i = 1; i <= n; i++)
            {
                sum += k + 1 / k;
            }
            return sum;
        }
        public static void Main(string[] args)
        {
            while (true) {
                Console.Clear();
                Console.WriteLine("#####MENU#####");
                Console.WriteLine("1.Обчислить функцию");
                Console.WriteLine("2.Наименьшее число");
                Console.WriteLine("3.Определить месяц");
                Console.WriteLine("4.Произведение n членов ряда");
                Console.Write("\nВведите команду:");
                char ch = char.Parse(Console.ReadLine());
                switch (ch)
                {
                    case '1':
                        Console.Write("Введите число: ");
                        double x = Convert.ToDouble(Console.ReadLine());
                        Console.WriteLine(Func(x));
                        Console.ReadKey();
                        break;
                    case '2':
                        Console.Write("Введите первое число: ");
                        int a = Convert.ToInt32(Console.ReadLine());

                        Console.Write("Введите первое число: ");
                        int b = Convert.ToInt32(Console.ReadLine());

                        Console.Write("Введите первое число: ");
                        int c = Convert.ToInt32(Console.ReadLine());

                        if (a < b && a < c)
                            Console.WriteLine("Минимальное число = " + a);
                        else if (b < c)
                            Console.WriteLine("Минимальное число = " + b);
                        else
                            Console.WriteLine("Минимальное число = " + c);
                        Console.ReadKey();
                        break;
                    case '3':
                        Console.Write("Введите число месяца: ");
                        int d = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine(Month(d));
                        Console.ReadKey();
                        break;
                    case '4':
                        Console.Write("Введите число n: ");
                        double n = Convert.ToDouble(Console.ReadLine());
                        int k = 1;
                        Console.WriteLine(Cycle(n, k));
                        Console.ReadKey();
                        break;
                }
            }
        }
    }
}
