﻿using System.Collections.Generic;
using System.Linq;

namespace Lab_12
{
    public class Trains//Сущность поездов как коллекции
    {
        public List<Train> ListTrains { get; set; }
        public void AddTrain(Train train) =>
            ListTrains.Add(train);
        public void DeleteTrain(Train train) =>
            ListTrains.Remove(train);
        public void AddTicket(Train train, Passenger person)
        {
            if (train.NumberOfFreePlaces > 0 && !person.HaveTicket)
            {
                train.NumberBuyTicket++;
                person.Ticket = new Ticket(train, person);
            }
        }
        public void AddBroke(Train train, Passenger person)
        {
            if (train.NumberOfFreePlaces > 0 && !person.HaveBroke)
            {
                train.BookedPlaces++;
                person.Broke = new Broke(train, person);
            }
        }
        public void DeleteTicket(Train train, Passenger person)
        {
            if (train.NumberBuyTicket > 0 && person.HaveTicket)
                train.NumberBuyTicket--;
            person.Ticket = null;
        }
        public void DeleteBroke(Train train, Passenger person)
        {
            if (train.BookedPlaces > 0 && person.HaveBroke)
                train.BookedPlaces--;
            person.Broke = null;
        }
        public void SortByNumberPerson() =>
            ListTrains.OrderBy(x => x.NumberOfPersons);//Сортировка по количеству человек в поезде
        public void ShowInfo() =>
            ListTrains.ForEach(x => x.Show());
    }
}
