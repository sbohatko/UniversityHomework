﻿using System;

namespace Lab_12
{
    public class Passenger//класс пасажир
    {
        public string Name { get; set; }
        public int Age { get; set; }
        public bool HaveTicket { get { return Ticket != null; } }//Есть ли билет у пассажира
        public Ticket Ticket { get; set; }
        public bool HaveBroke { get { return Broke != null; } } //Есть ли бронь у пассажира
        public Broke Broke { get; set; }
        public void Show()=>
            Console.WriteLine("Name:{0}\nAge:{1}\nHaveTicket:{2}\nHaveBroke:{3}",Name,Age,HaveTicket,HaveBroke);//Вывод инфы о пассажире
    }
}