﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Lab_12
{
    class Program
    {
        static void Main(string[] args)
        {
            var sasha = new Passenger { Name = "Sasha", Age = 19 };
            var anya = new Passenger { Name = "Anya", Age = 18 };//инициальзируем поссажиров
            var trains = new Trains
            {
                ListTrains = new List<Train>{
                new Train
                {
                    NumberOfSeats = 10,
                    Name = "Ukrzaliznitsa"
                },new Train{NumberOfSeats = 15,
                    Name = "Kiev-Praha", }
                }
            };//инициализируем поезда
            trains.ShowInfo();
            Console.WriteLine();
            sasha.Show();
            Console.WriteLine();
            anya.Show();
            trains.AddTicket(trains.ListTrains.First(x => x.Name == "Ukrzaliznitsa"),sasha);//Добавляем билет
            Console.WriteLine();
            sasha.Show();
            trains.AddBroke(trains.ListTrains.First(x => x.Name == "Kiev-Praha"),anya);//Добавляем бронь
            Console.WriteLine();
            anya.Show();
            Console.WriteLine();
            trains.ShowInfo();//Выводим инфу о всех поездах
            trains.ListTrains.First(x => x.Name == "Ukrzaliznitsa").Go();
            trains.ListTrains.First(x => x.Name == "Kiev-Praha").Go();
            trains.AddTrain(new Train
            {
                NumberOfSeats = 20,
                Name = "ToMars"
            });//Добавляем поезд
            var elon = new Passenger { Name = "Elon Musk", Age = 16 };
            Console.WriteLine();
            elon.Show();
            trains.AddTicket(trains.ListTrains.First(x => x.Name == "ToMars"), elon);
            Console.WriteLine();
            trains.ShowInfo();
            trains.ListTrains.First(x => x.Name == "ToMars").Go();
            Console.WriteLine();
            trains.ShowInfo();
            Console.ReadLine();
        }
    }
}
