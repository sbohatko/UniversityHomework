﻿
namespace Lab_12
{
    public class Broke//Класс бронь
    {
        public Train Train { get; set; }
        public Passenger Passenger { get; set; }

        public Broke(Train train, Passenger passenger)
        {
            Train = train;
            Passenger = passenger;
        }
    }
}
