﻿using System;
using System.Collections.Generic;

namespace Lab_12
{
    public class Train
    {
        public string Name { get; set; }
        public int NumberOfSeats = 0;
        public int BookedPlaces = 0;
        public int NumberBuyTicket = 0;
        public int NumberOfPersons
        {
            get
            {
                return BookedPlaces + NumberBuyTicket;
            }
        }
        public int NumberOfFreePlaces { get { return NumberOfSeats - NumberOfPersons; } }
        public List<Passenger> Persons { get; set; }
        public void Go()
        {
            Console.WriteLine("{0} Go!", Name);
            NumberBuyTicket = 0;
            BookedPlaces = 0;
            Persons = new List<Passenger>();
        }
        public void Show() =>
            Console.WriteLine("Name:{0}\nNumberOfSeats:{1}\nBookedPlaces:{2}\nNumberOfFreePlaces:{3}\n\n"
                , Name, NumberOfSeats, BookedPlaces, NumberOfFreePlaces);
    }
}
