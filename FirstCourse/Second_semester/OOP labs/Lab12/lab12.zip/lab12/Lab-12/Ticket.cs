﻿
namespace Lab_12
{
    public class Ticket//Класс билет
    {
        public Train Train { get; set; }
        public Passenger Passenger { get; set; }

        public Ticket(Train train, Passenger passenger)
        {
            Train = train;
            Passenger = passenger;
        }
    }
}
