﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lab_14
{
    public class Consumers//the essence of the inhabitants
    {
        public List<Consumer> ListConsumers { get; set; }
        public void GetInfo()
        {
            foreach (var item in ListConsumers)
            {
                item.ShowInfo();
            }
        }

    }
}
