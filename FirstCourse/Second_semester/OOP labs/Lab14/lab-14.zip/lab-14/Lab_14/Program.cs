﻿using System;
using System.Collections.Generic;

namespace Lab_14
{
    class Program
    {
        static void Main(string[] args)
        {
            var ivan = new Consumer { Name="Ivan",Age=24,Resources=15000};
            var olga = new Consumer { Name = "Olga", Age = 26, Resources = 6000 };
            var kirill = new Consumer { Name = "Kirill", Age = 28, Resources = 10000 };
            var familyhouse = new JointProperty
            {
                Consumers = new Consumers
                {
                    ListConsumers = new List<Consumer> { olga, kirill }
                },
                DebtForElectricityInMonth = 6000,
                DebtForGasInMonth = 4000
            };
            var ivanhouse = new SingleHousehold
            {
                Consumer=ivan,
                DebtForElectricityInMonth = 4500,
                DebtForGasInMonth = 2500
            };
            ivan.ShowInfo();
            olga.ShowInfo();
            kirill.ShowInfo();
            Console.WriteLine("StepMouth");
            familyhouse.StepMonth();
            ivanhouse.StepMonth();
            ivan.ShowInfo();
            familyhouse.Consumers.GetInfo();
            ivanhouse.PayForGas(ivan, 3000);
            familyhouse.PayForGas(olga, 3000);
            familyhouse.PayForElectricity(kirill, 3000);
            ivan.ShowInfo();
            familyhouse.Consumers.GetInfo();
            Console.ReadLine();
        }
    }
}
