﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lab_14
{
    public class Consumer//resident nature
    {
        public string Name { get; set; }
        public int Age { get; set; }
        public decimal Resources { get; set; }
        public decimal DebtForGas { get; set; }
        public decimal DebtForElectricity { get; set; }
        public void ShowInfo() =>
            Console.WriteLine("Name:{0}   Age:{1}   Resources:{2}   Debt for gas:{3}   Debt for electricity:{4}"
                , Name, Age, Resources, DebtForGas, DebtForElectricity);
    }
}
