﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lab_14
{
    public class JointProperty : HomeOwnership
    {
        public Consumers Consumers { get; set; }
        public override decimal GasDebt//method HomeOwnership implementation
        {
            get
            {
                decimal debt=0;
                Consumers.ListConsumers.ForEach(x => debt += x.DebtForGas);
                return debt;
            }
            set {; }
        }
        public override decimal ElectricityDebt//method HomeOwnership implementation
        {
            get
            {
                decimal debt = 0;
                Consumers.ListConsumers.ForEach(x => debt += x.DebtForElectricity);
                return debt;
            }
            set {; }

        }
        public override void StepMonth()//method HomeOwnership implementation
        {
            foreach (var consumer in Consumers.ListConsumers)
            {
                consumer.DebtForElectricity += DebtForElectricityInMonth;
                consumer.DebtForGas += DebtForGasInMonth;
            }
         
        }

    }
}
