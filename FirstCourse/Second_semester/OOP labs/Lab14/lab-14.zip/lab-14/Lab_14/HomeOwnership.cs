﻿using System;
using System.Collections.Generic;
using System.Security.Principal;
using System.Text;

namespace Lab_14
{
    public abstract class HomeOwnership//abstract communal class
    {
        public decimal DebtForGasInMonth { get; set; }
        public decimal DebtForElectricityInMonth { get; set; }
        public abstract decimal GasDebt { get; set; }
        public abstract decimal ElectricityDebt { get; set; }
        public void ShowDeptForGasInMonth() =>
            Console.WriteLine("Debt for gas in month:" + DebtForGasInMonth);
        public void ShowDeptForElectricityInMonth() =>
            Console.WriteLine("Debt for electricity in month:" + DebtForElectricityInMonth);
        public void ShowDeptForGas() =>
            Console.WriteLine("Debt for gas:" + DebtForGasInMonth);
        public void ShowDeptForElectricity() =>
            Console.WriteLine("Debt for electricity:" + DebtForElectricityInMonth);
        public void PayForGas(Consumer consumer,decimal price)//gas payment method
        {
            if (consumer.Resources >= price)
            {

                if (consumer.DebtForGas >= price)
                {
                    consumer.DebtForGas -= price;
                    consumer.Resources -= price;
                    Console.WriteLine("{0} Pay for gas:{1}\nDebtForGas:{2}",consumer.Name, price,
                       consumer.DebtForGas);
                }
                else
                {
                    var tempprice = consumer.DebtForGas;
                    consumer.Resources -= consumer.DebtForGas;
                    consumer.DebtForGas = 0;
                    Console.WriteLine("{0} Pay for gas:{1}\nDebtForGas:{2}", consumer.Name, tempprice,
                        consumer.DebtForGas);
                }
            }
            else
            {
                Console.WriteLine("Not enough money");
            }
        }
        public void PayForElectricity(Consumer consumer, decimal price)//electricity payment method
        {
            if (consumer.Resources >= price)
            {

                if (consumer.DebtForElectricity >= price)
                {
                    consumer.DebtForElectricity -= price;
                    consumer.Resources -= price;
                    Console.WriteLine("{0} Pay for electricity:{1}\nDebtForElectricity:{2}",consumer.Name, price,
                       consumer.DebtForElectricity);
                }
                else
                {
                    var tempprice = consumer.DebtForElectricity;
                    consumer.Resources -= consumer.DebtForElectricity;
                    consumer.DebtForElectricity = 0;
                    Console.WriteLine("{0} Pay for electricity:{1}\nDebtForElectricity:{2}", consumer.Name ,tempprice,
                        consumer.DebtForElectricity);
                }
            }
            else
            {
                Console.WriteLine("Not enough money");
            }    
        }
        public abstract void StepMonth();//method for increasing public service debt
    }
}
