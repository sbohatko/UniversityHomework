﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lab_14
{
    public class SingleHousehold:HomeOwnership
    {
        public Consumer Consumer { get; set; }

        public override decimal GasDebt
        {
            get
            {
                return Consumer.DebtForGas;
            }
            set {; }
        }
        public override decimal ElectricityDebt
        {
            get
            {
                return Consumer.DebtForElectricity;
            }
            set {; }
        }
        public override void StepMonth()
        {
            Consumer.DebtForElectricity += DebtForElectricityInMonth;
            Consumer.DebtForGas += DebtForGasInMonth;
        }
    }
}
